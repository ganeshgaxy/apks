# Selenide Appium Android

Selenide is build on top of selenium which offers way simpler and better approaches than classic selenium.
Selenide adaptor for Appium framework.

This demo only has test cases for Android.

### How to run the example

* Run the emulator:

  Emulator which is being used in this demo is x86_64 as my windows support x86.
  This setup is just to enhance app performance.
  Emulator does not have any google apis to increase performance.
  Instagram apk which is used in this demo also supports x86.
  Try not to switch apk or emulator as it may cause ABIs error.

  > open Android Studio -> "Android Virtual Device Manager" -> Run

* Run appium server:
   > appium

* And finally, run the test:
   > ./gradlew cucumberCli
