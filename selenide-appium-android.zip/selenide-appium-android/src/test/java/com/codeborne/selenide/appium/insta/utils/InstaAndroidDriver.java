package com.codeborne.selenide.appium.insta.utils;

import com.codeborne.selenide.WebDriverProvider;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import javax.annotation.Nonnull;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;

import static org.apache.commons.io.FileUtils.copyInputStreamToFile;

public class InstaAndroidDriver implements WebDriverProvider {
  /**
   * to create driver, an implemented method from base interface
   * @param capabilities desired capabilities to make android app up and running
   * @return android driver to carry on scenario execution
   */
  @Nonnull
  @Override
  public WebDriver createDriver(@Nonnull DesiredCapabilities capabilities) {
    File app = downloadApk();
    capabilities.setCapability(MobileCapabilityType.VERSION, "4.4.2");
    capabilities.setCapability("automationName", "Appium");
    capabilities.setCapability("platformName", "Android");
    capabilities.setCapability("deviceName", "Android Emulator");
    capabilities.setCapability("app", app.getAbsolutePath());
    capabilities.setCapability("appPackage", "com.instagram.android");
    capabilities.setCapability("appActivity", ".activity.MainTabActivity");

    try {
      return new AndroidDriver<AndroidElement>(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
    } catch (MalformedURLException e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * to download the apk from github source
   * @return File will be downloaded and returned as simple file
   */
  private File downloadApk() {
    File apk = new File("build/Instagram.apk");
    if (!apk.exists()) {
      String url = "https://github.com/ganeshgaxy/apks/blob/main/Instagram.apk?raw=true";
      try (InputStream in = new URL(url).openStream()) {
        copyInputStreamToFile(in, apk);
      }
      catch (IOException e) {
        throw new AssertionError("Failed to download apk", e);
      }
    }
    return apk;
  }
}
