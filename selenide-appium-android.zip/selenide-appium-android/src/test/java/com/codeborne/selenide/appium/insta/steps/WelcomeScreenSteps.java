package com.codeborne.selenide.appium.insta.steps;

import com.codeborne.selenide.appium.insta.screens.WelcomeScreen;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import static com.codeborne.selenide.appium.ScreenObject.screen;

public class WelcomeScreenSteps {
  WelcomeScreen welcomeScreen = screen(WelcomeScreen.class);

  @Given("[WelcomeScreen] The current page is Pre Login")
  public void theCurrentPageIsPreLogin() {
    welcomeScreen.assertVisibilityOfSignupButton();
    welcomeScreen.assertVisibilityOfLoginButton();
  }

  @And("[WelcomeScreen] Go to Login screen")
  public void goToLoginScreen() {
    welcomeScreen.clickOnLoginButton();
  }

  @And("[WelcomeScreen] Go to Signup screen")
  public void goToSignupScreen() {
    welcomeScreen.clickOnSignupButton();
  }
}
