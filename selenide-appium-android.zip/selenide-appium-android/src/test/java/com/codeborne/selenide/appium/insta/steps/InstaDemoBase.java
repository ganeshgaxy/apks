package com.codeborne.selenide.appium.insta.steps;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.appium.insta.utils.InstaAndroidDriver;
import io.cucumber.java.After;
import io.cucumber.java.Before;

import static com.codeborne.selenide.Selenide.closeWebDriver;
import static com.codeborne.selenide.Selenide.open;

public class InstaDemoBase {
  /**
   * to setup the driver along with app to trigger the test cases before every scenario
   */
  @Before
  public void setup(){
    closeWebDriver();
    Configuration.startMaximized=false;
    Configuration.browserSize = null;
    Configuration.browser= InstaAndroidDriver.class.getName();
    open();
  }

  /**
   * to teardown the driver after very scenario
   */
  @After
  public void tearDown() {
    closeWebDriver();
  }
}
