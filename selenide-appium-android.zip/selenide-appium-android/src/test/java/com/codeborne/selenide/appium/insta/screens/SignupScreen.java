package com.codeborne.selenide.appium.insta.screens;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.By;

import static com.codeborne.selenide.Selenide.$;

public class SignupScreen extends TestBase{
  @AndroidFindBy(id = "com.instagram.android:id/right_tab")
  SelenideElement emailTab;

  @AndroidFindBy(id = "com.instagram.android:id/email_field")
  SelenideElement emailTextBox;

  @AndroidFindBy(id = "com.instagram.android:id/button_text")
  SelenideElement nextButton;

  /**
   * to select the Email tab
   */
  public void selectEmailTab(){
    emailTab.click();
  }

  /**
   * to set email in the email text bos
   * @param email email as string
   */
  public void setEmail(String email){
    emailTextBox.shouldBe(Condition.visible);
    emailTextBox.sendKeys(email);
  }

  /**
   * to click on the next button
   */
  public void clickOnNextButton(){
    nextButton.shouldBe(Condition.enabled);
    nextButton.click();
  }

  /**
   * to assert if expected validation error message is visible
   * @param message expected validation error message as string
   */
  public void assertInvalidEmailMessage(String message){
    $(By.xpath(String.format("//*[@text='%s']", message))).shouldBe(Condition.visible);
  }
}
