package com.codeborne.selenide.appium.insta.steps;

import com.codeborne.selenide.appium.insta.screens.SignupScreen;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import static com.codeborne.selenide.appium.ScreenObject.screen;

public class SignupScreenSteps {
  SignupScreen signupScreen = screen(SignupScreen.class);

  @Then("[SignupScreen] Switch to Email tab")
  public void switchToEmailTab() {
    signupScreen.selectEmailTab();
  }

  @Then("[SignupScreen|Email] Signup with email {string}")
  public void signupWithEmail(String email) {
    signupScreen.setEmail(email);
    signupScreen.clickOnNextButton();
  }

  @And("[SignupScreen|Email] Signup should be failed with message {string}")
  public void signupShouldBeFailedWithMessage(String errorMsg) {
    signupScreen.assertInvalidEmailMessage(errorMsg);
  }
}
