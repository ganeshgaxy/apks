package com.codeborne.selenide.appium.insta.screens;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.appium.java_client.pagefactory.AndroidFindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.assertj.core.api.Assertions.assertThat;

public class LoginScreen extends TestBase {

  /**
   * Locators - Elements in the android app
   */

  @AndroidFindBy(id = "com.instagram.android:id/login_username")
  SelenideElement usernameTextBox;

  @AndroidFindBy(id = "com.instagram.android:id/password")
  SelenideElement passwordTextBox;

  @AndroidFindBy(id = "com.instagram.android:id/button_text")
  SelenideElement loginButton;

  @AndroidFindBy(id = "com.instagram.android:id/button_progress")
  SelenideElement loginProgress;

  @AndroidFindBy(id = "com.instagram.android:id/default_dialog_title")
  SelenideElement loginDialogTitle;

  /**
   * to set username text box with provided value
   * @param username username as string
   */
  public void setUsername(String username) {
    usernameTextBox.shouldBe(Condition.visible);
    usernameTextBox.sendKeys(username);
  }

  /**
   * to set password text box with provided value
   * @param password password as string
   */
  public void setPassword(String password) {
    passwordTextBox.shouldBe(Condition.visible);
    passwordTextBox.sendKeys(password);
  }

  /**
   * to assert if login button is disabled in the screen
   */
  public void assertLoginButtonIsDisabled(){
    loginButton.shouldBe(Condition.visible);
    loginButton.shouldBe(Condition.disabled);
  }

  /**
   * to login to the app with given username and password
   * @param username username as string
   * @param password password as string
   */
  public void loginToApp(String username, String password){
    setUsername(username);
    setPassword(password);
    loginButton.click();
  }

  /**
   * to wait until the login progress evades
   */
  public void waitUntilLoginProgressDisappears(){
    (new WebDriverWait(driver(),120)).until(ExpectedConditions.invisibilityOf(loginProgress));
  }

  /**
   * to assert if the expected error message appears on the screen
   * @param expectedTitle expected error message as string
   */
  public void assertLoginDialogTitle(String expectedTitle){
    loginDialogTitle.shouldBe(Condition.visible);
    assertThat(loginDialogTitle.getText()).isEqualTo(expectedTitle);
  }
}
