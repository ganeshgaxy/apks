package com.codeborne.selenide.appium.insta.screens;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.SelenideElement;
import io.appium.java_client.pagefactory.AndroidFindBy;

public class WelcomeScreen extends TestBase{
  @AndroidFindBy(id = "com.instagram.android:id/sign_up_with_email_or_phone")
  SelenideElement signupButton;

  @AndroidFindBy(id = "com.instagram.android:id/log_in_button")
  SelenideElement loginButton;

  /**
   * to click on login button in the screen
   */
  public void clickOnLoginButton(){
    loginButton.click();
  }

  /**
   * to click on signup button in the screen
   */
  public void clickOnSignupButton(){
    signupButton.click();
  }

  /**
   * to assert visibility of the signup button in the screen
   */
  public void assertVisibilityOfSignupButton(){
    signupButton.shouldBe(Condition.visible);
  }

  /**
   * to assert visibility of the login button in the screen
   */
  public void assertVisibilityOfLoginButton(){
    loginButton.shouldBe(Condition.visible);
  }
}
