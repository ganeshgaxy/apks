package com.codeborne.selenide.appium.insta.steps;

import com.codeborne.selenide.appium.insta.screens.LoginScreen;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

import static com.codeborne.selenide.appium.ScreenObject.screen;

public class LoginScreenSteps {
  LoginScreen loginScreen = screen(LoginScreen.class);

  @Then("[LoginScreen] Try logging in with username {string} and password {string}")
  public void tryLoggingInWithUsernameAndPassword(String username, String password) {
    loginScreen.loginToApp(username, password);
    loginScreen.waitUntilLoginProgressDisappears();
  }

  @And("[LoginScreen] Login should be failed with message {string}")
  public void loginShouldBeFailedWithMessage(String expectedFailureText) {
    loginScreen.assertLoginDialogTitle(expectedFailureText);
  }

  @Then("[LoginScreen] Try logging in with only username {string}")
  public void tryLoggingInWithOnlyUsername(String username) {
    loginScreen.setUsername(username);
    loginScreen.assertLoginButtonIsDisabled();
  }
}
