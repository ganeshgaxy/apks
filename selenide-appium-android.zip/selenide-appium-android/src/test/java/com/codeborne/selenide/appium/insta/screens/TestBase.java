package com.codeborne.selenide.appium.insta.screens;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import static com.codeborne.selenide.WebDriverRunner.getWebDriver;

public abstract class TestBase {

  /**
   * To expose driver in case of any driver level actions
   * @return driver() function will expose the driver
   */
  @SuppressWarnings("unchecked")
  public AndroidDriver<AndroidElement> driver() {
    return (AndroidDriver<AndroidElement>) getWebDriver();
  }
}
